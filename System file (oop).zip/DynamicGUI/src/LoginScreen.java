

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JToolBar;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.JSplitPane;
import javax.swing.JLayeredPane;
import javax.swing.JEditorPane;
import javax.swing.JTree;



public class LoginScreen extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textName;
    private JTextField textPassword;
    private JPasswordField passwordField;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LoginScreen frame = new LoginScreen();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public LoginScreen() {
        setTitle("Dish Data"); // Add title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 563, 324);
        setLocationRelativeTo(null); // Center on screen

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel password = new JLabel("Password");
        password.setBounds(46, 104, 99, 27);
        contentPane.add(password);
        
        JLabel username = new JLabel("Username");
        username.setBounds(46, 64, 72, 14);
        contentPane.add(username);
        
        textName = new JTextField();
        textName.setBounds(200, 61, 189, 20);
        contentPane.add(textName);
        textName.setColumns(10);
        
        textPassword = new JTextField();
        textPassword.setBounds(200, 107, 189, 20);
        contentPane.add(textPassword);
        textPassword.setColumns(10);
        
        JLabel Signup = new JLabel("Sign Up");
        Signup.setBounds(279, 172, 46, 14);
        contentPane.add(Signup);
        
        JButton btnLogin = new JButton("Log in");
        btnLogin.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnLogin.setBounds(255, 138, 89, 23);
        contentPane.add(btnLogin);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(200, 107, 189, 20);
        contentPane.add(passwordField);
        
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(144, 11, 1, 1);
        contentPane.add(layeredPane);

        // Example: You can now add Swing components here
        // e.g., username/password fields, login button, etc.
    }
}
